<template>
  <q-card-actions align="right">
    <q-btn
      color="primary"
      label="Save"
      type="submit"
    />
  </q-card-actions>
</template>

<script>
export default {

}
</script>