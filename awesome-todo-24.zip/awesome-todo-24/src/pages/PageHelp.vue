<template>
  <q-page padding>
    <q-btn
      to="/settings"
      color="primary"
      icon="chevron_left"
      label="Back"
      flat
    />

    <h5>How to use Awesome Todo</h5>
    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Sequi cumque, voluptate eius inventore hic aspernatur. Suscipit blanditiis iusto eveniet vitae temporibus debitis omnis voluptatibus eos aliquid, magnam quae, animi tempora.</p>
  </q-page>
</template>

<script>
export default {

}
</script>